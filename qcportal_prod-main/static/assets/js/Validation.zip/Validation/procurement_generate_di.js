function validateForm() {
    //var quantity = document.forms["myForm"]["quantity"].value;
    let exampleInputEmail1_12 = document.getElementById('exampleInputEmail1_566').value;
    console.log(exampleInputEmail1_12);


}